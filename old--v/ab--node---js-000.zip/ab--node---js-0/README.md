# node--js--connect--events
- connected client send msg to server.js
- event listeners on keys or when mouse inside canvas
- send that data to server and other clients
- "dependencies": {
    "express": "^4.17.1",
    "socket.io": "^4.1.3"
  }
