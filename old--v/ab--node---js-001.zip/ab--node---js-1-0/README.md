# node--js--connect--events
## - v1
- connect disconnect event
- client array 
- push pop
- player constructor 
- server push player location
- client draw new players
- todo: save other players locations push that drawing before drawing new players
## - v0
- connected client send msg to server.js
- event listeners on keys or when mouse inside canvas
- send that data to server and other clients
## - "dependencies": { }
   - "express": "^4.17.1",
   - "socket.io": "^4.1.3"
