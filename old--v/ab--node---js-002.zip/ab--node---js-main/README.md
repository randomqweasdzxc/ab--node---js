# node--js--connect--events
## - v-1-1
- cleaned some useless stuff atm
- earlier todo must be done is diferent events?
- client connect handle of who is connected, array of ids as strings,
- client disconnect splice data array handle
- array of objects? each object contains id and position? 
## - "dependencies": { }
   - "express": "^4.17.1",
   - "socket.io": "^4.1.3"
